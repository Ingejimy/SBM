#include "cmsis_os2.h"                          // CMSIS RTOS header file
#include "Thled2.h"
/*----------------------------------------------------------------------------
 *      Thread 2 'Thread_Name': Sample thread
 *---------------------------------------------------------------------------*/
 
osThreadId_t tid_Thled2;                        // thread id
 
void Thled2 (void *argument);                   // thread function
 
int Init_Thled2 (void) {
 
  tid_Thled2 = osThreadNew(Thled2, NULL, NULL);
  if (tid_Thled2 == NULL) {
    return(-1);
  }
 
  return(0);
}
 
void Thled2 (void *argument) {
	

  uint32_t   delayTime1 = 137;
	
  while (1) {
		HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_7);
    osDelay(delayTime1); // Insert thread code here...
		HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_7);
		osDelay(delayTime1);
    osThreadYield();                            // suspend thread
  }
}

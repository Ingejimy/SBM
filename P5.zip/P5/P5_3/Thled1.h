#include "stm32f4xx_hal.h"

/* Flags*/
#define S_LED2 0x00000001

/* Prototipo de funciones*/
int Init_Thled1 (void);

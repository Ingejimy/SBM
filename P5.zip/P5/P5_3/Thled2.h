#include "stm32f4xx_hal.h"

/* Flags*/
#define S_LED2 0x00000001
#define S_LED3 0x00000002
/* Prototipo de funciones*/
int Init_Thled2 (void);

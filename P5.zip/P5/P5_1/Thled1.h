#include "stm32f4xx_hal.h"

/* Prototipo de funciones*/
int Init_Thled1 (void);

#include "cmsis_os2.h"                          // CMSIS RTOS header file
#include "Thjoy.h"


/*----------------------------------------------------------------------------
*      Thread Driver Jostick: Para gestionar los rebotes
 *---------------------------------------------------------------------------*/


osThreadId_t tid_Thjoy;                        /* thread id del Driver */
osThreadId_t tid_ThPulsacionLarga;
osTimerId_t tim_id1;   												 /* Timer virtual id */
osTimerId_t tim_id2;   												 /* Timer virtual id */
osMessageQueueId_t mid_MsgQueueJOY; 							 /* id de la cola de mensajes */

static int pulsacion;																 /* cuenta las veces que pulsamos */
static uint8_t msg_joy;									       		 /* Donde almacenamos el mensaje. LOCAL */
static uint32_t exec1;                         /* argument for the timer call back function */
static uint32_t exec2;                         /* argument for the timer call back function */
static int cnt;

extern osThreadId_t tid_ThMsg;  

void Thjoy (void *argument);                   
void ThPulsacionLarga (void *argument);

/* Thread que espera una pulsacion del Jostick e inicia el timer virtual */
int Init_Thjoy (void) {
 
  tid_Thjoy = osThreadNew(Thjoy, NULL, NULL);
  if (tid_Thjoy == NULL) {
    return(-1);
  }
  return(0);
}

void Thjoy (void *argument) {
	
	pulsacion = 0;
  while (1) {
		
		osThreadFlagsWait(S_START_TIM, osFlagsWaitAll, osWaitForever);
		Init_Timers();
		//osTimerStart(tim_id1, 50U);
    osThreadYield();                            // suspend thread
  }
}

/* Thread que inicia timer para diferenciar una pulsacion laga de la corta */
int Init_ThPulsacionLarga (void) {
 
  tid_ThPulsacionLarga = osThreadNew(ThPulsacionLarga	, NULL, NULL);
  if (tid_ThPulsacionLarga == NULL) {
    return(-1);
  }
  return(0);
}

void ThPulsacionLarga (void *argument) {
	
	cnt = 0;
 
  while (1) {
		
		osThreadFlagsWait(S_PULSACION, osFlagsWaitAll, osWaitForever);
		Init_Timer2();
		//osTimerStart(tim_id2, 50U);
		
		osThreadFlagsWait(S_PULSACION_FIN, osFlagsWaitAll, osWaitForever);
		osTimerStop(tim_id2);
		if(cnt < 20){
			msg_joy = 0x10U;
		}
		else{
			msg_joy = 0x20U;
		}
		osMessageQueuePut(mid_MsgQueueJOY, &msg_joy, 0U, 0U);
		cnt = 0;
		
    osThreadYield();                            // suspend thread
  }
}

// One-Shoot Timer
static void Timer1_Callback (void const *arg) {
	
	/* Arriba */
		if( HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_10) == 1 ){
			pulsacion++;

			msg_joy = 0x01U;
			osMessageQueuePut(mid_MsgQueueJOY, &msg_joy, 0U, 0U);
		}
		
		/* Derecha */
		if( HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_11) == 1 ){
			pulsacion++;

			msg_joy = 0x02U;
			osMessageQueuePut(mid_MsgQueueJOY, &msg_joy, 0U, 0U);
		}
		
		/* Abajo */
		if( HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_12) == 1 ){
			pulsacion++;
			
			msg_joy = 0x04U;
			osMessageQueuePut(mid_MsgQueueJOY, &msg_joy, 0U, 0U);
		}
		
		/* Izquierda */
		if( HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_14) == 1 ){
			pulsacion++;
			
			msg_joy = 0x08U;
			osMessageQueuePut(mid_MsgQueueJOY, &msg_joy, 0U, 0U);
		}
		
		/* Centro */
		if( HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_15) == 1 ){
			osThreadFlagsSet(tid_ThPulsacionLarga, S_PULSACION);
			pulsacion++;
		}
}

// Creamos e inicializamos timer virtual
int Init_Timers (void) {
  osStatus_t status;                            // function return status
 
  // Create one-shoot timer
  exec1 = 1U;
  tim_id1 = osTimerNew((osTimerFunc_t)&Timer1_Callback, osTimerOnce, &exec1, NULL);
  if (tim_id1 != NULL) {  // One-shot timer created
    // start timer with delay 50ms
    status = osTimerStart(tim_id1, 50U); 
    if (status != osOK) {
      return -1;
    }
  }
	
  return NULL;
}

// Periodic Timer
static void Timer2_Callback (void const *arg) {
	
	if( HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_15) == 1 && cnt < 20 )
	cnt++;
	else
		osThreadFlagsSet(tid_ThPulsacionLarga, S_PULSACION_FIN);
		
}

// Creamos e inicializamos timer virtual
int Init_Timer2 (void) {
  osStatus_t status;                            // function return status
 
  // Create periodic timer
  exec2 = 2U;
  tim_id2 = osTimerNew((osTimerFunc_t)&Timer2_Callback, osTimerPeriodic, &exec2, NULL);
  if (tim_id2 != NULL) {  // One-shot timer created
    // start timer with delay 50ms
    status = osTimerStart(tim_id2, 50U); 
    if (status != osOK) {
      return -1;
    }
  }
	
  return NULL;
}

/* Inicializamos la cola de mesajes */
int Init_MsgQueueJOY(void){
	mid_MsgQueueJOY = osMessageQueueNew(MAX_MSG_COLA, sizeof(msg_joy), NULL);
	if (mid_MsgQueueJOY == NULL){}
		
	return(0);
}


#include "stm32f4xx_hal.h"

/* Flags */


/* Prototipos de funciones*/
int Init_ThPrincipal(void);

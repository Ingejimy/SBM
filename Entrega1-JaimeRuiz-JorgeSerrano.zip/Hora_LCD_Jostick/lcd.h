#include "stdint.h"


void delay(uint32_t n_milisegundos);
void LCD_reset(void);
void LCD_wr_data(unsigned char data);
void LCD_wr_cmd(unsigned char cmd);
void LCD_init(void);
void LCD_update(void);
void LCD_symbolToLocalBuffer_L1(uint8_t symbol);
void LCD_symbolToLocalBuffer_L2(uint8_t symbol);
void symbolToLocalBuffer(uint8_t line, uint8_t symbol);

void LCD_limpiar(void);
//void LCD_escribir_linea(const char buffer_palabra1[],const char buffer_palabra2[]);

#include "stm32f4xx_hal.h"
#include "lcd.h"

/* Numero m�ximo de mensajes en la cola*/
#define MAX_MSG_LCD 5

typedef struct {
  char Texto[50];
  uint8_t Linea;
} MSG_LCD;

/* Prototipos de funciones */
int Init_ThLCD(void);
int Init_MsgQueueLCD(void);

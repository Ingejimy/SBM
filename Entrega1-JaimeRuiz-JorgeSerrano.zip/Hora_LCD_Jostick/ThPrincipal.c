#include "cmsis_os2.h"                          // CMSIS RTOS header file
#include "Thjoy.h"
#include "ThLCD.h"
#include "stdio.h"
#include "ThHora.h"

/*----------------------------------------------------------------------------
*      ThpPrincipal: Se encarga de la comunicacion de todos los modulos
 *---------------------------------------------------------------------------*/
 
osThreadId_t tid_ThPrincipal;                        // thread id

static uint8_t modo;
static uint8_t msg_joy;
static uint8_t msg_joy_aux;
static MSG_LCD mensajeLCD;

extern osMessageQueueId_t mid_MsgQueueJOY;
extern osMessageQueueId_t mid_MsgQueueLCD;
extern int horas;
extern int minutos;
extern int segundos;

void ThPrincipal (void *argument);                   // thread function
 
int Init_ThPrincipal (void) {
 
  tid_ThPrincipal = osThreadNew(ThPrincipal, NULL, NULL);
  if (tid_ThPrincipal == NULL) {
    return(-1);
  }
 
  return(0);
}
 
void ThPrincipal (void *argument) {
	
		modo = 0; // Modo reposo
  while (1) {
		
		
		switch(modo){
			/* REPOSO*/
			case 0:
				LCD_limpiar();
				mensajeLCD.Linea = 1;
				sprintf(mensajeLCD.Texto, " SBM 2022  T: xx.xx C");
				osMessageQueuePut(mid_MsgQueueLCD, &mensajeLCD, NULL, 0U);

				mensajeLCD.Linea = 2;
			sprintf(mensajeLCD.Texto, "      %.2d:%.2d:%.2d", horas, minutos, segundos);
				osMessageQueuePut(mid_MsgQueueLCD, &mensajeLCD, NULL, 0U);
			break;
					
			/* RADIO MANUAL*/
			case 1:
				LCD_limpiar();
				mensajeLCD.Linea = 1;
				sprintf(mensajeLCD.Texto, "RADIO MANUAL");
				osMessageQueuePut(mid_MsgQueueLCD, &mensajeLCD, NULL, 0U);
				break;
				
			/* RADIO MEMORIA*/
			case 2:
				LCD_limpiar();
				mensajeLCD.Linea = 1;
				sprintf(mensajeLCD.Texto, "RADIO MEMORIA");
				osMessageQueuePut(mid_MsgQueueLCD, &mensajeLCD, NULL, 0U);
				break;
						
			/* PROGRAMACION DE HORA*/
			default:
				LCD_limpiar();
				mensajeLCD.Linea = 1;
				sprintf(mensajeLCD.Texto, "PROGRAMACION HORA");
				osMessageQueuePut(mid_MsgQueueLCD, &mensajeLCD, NULL, 0U);
				break;
		}
			
		if(osMessageQueueGet(mid_MsgQueueJOY, &msg_joy, NULL, 1000U) == osOK && msg_joy != msg_joy_aux)
			msg_joy_aux = msg_joy;
		else
			msg_joy_aux = 0;
		
		if(msg_joy_aux == 0x20){
					if(modo == 3)
						modo = 0;
					else
						modo++;
			}
		osThreadYield();                            // suspend thread
  }
}

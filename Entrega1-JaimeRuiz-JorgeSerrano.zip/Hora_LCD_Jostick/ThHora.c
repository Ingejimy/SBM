#include "cmsis_os2.h"                          // CMSIS RTOS header file
#include "ThHora.h"

/*----------------------------------------------------------------------------
 *      Timer: Timer que gestiona el reloj
 *---------------------------------------------------------------------------*/
/*Variables Globales*/
int horas;
int minutos;
int segundos;

/*----- Periodic Timer Example -----*/
osTimerId_t tim_Reloj;                            // timer id
static uint32_t exec2;                          // argument for the timer call back function

// Periodic Timer Function
static void TmrReloj_Callback (void const *arg) {
  // add user code here
	if(segundos<59){
		segundos++;
	}
	else{
		segundos = 0;
		if(minutos<59){
			minutos++;
		}
		else{
			minutos = 0;
			if(horas<23){
				horas++;
			}else{
				horas = 0;
			}
		}
	}
}
 
// Example: Create and Start timers

int Init_TmReloj (void) {
  osStatus_t status;                            // function return status
 
  // Create periodic timer
  exec2 = 2U;
  tim_Reloj = osTimerNew((osTimerFunc_t)&TmrReloj_Callback, osTimerPeriodic, &exec2, NULL);
  if (tim_Reloj != NULL) {  // Periodic timer created           
    status = osTimerStart(tim_Reloj, 1000U);
		if (status != osOK) {
      return -1;
    }
  }
	return NULL;
}

/* Thread que arranca el timer del reloj*/
 
osThreadId_t tid_ThReloj;                        // thread id

void ThReloj (void *argument);                   // thread function
 
int Init_ThReloj (void) {
 
  tid_ThReloj = osThreadNew(ThReloj, NULL, NULL);
  if (tid_ThReloj == NULL) {
    return(-1);
  }
 
  return(0);
}
 
void ThReloj (void *argument) {
	
		Init_TmReloj();
  while (1) {
		osThreadYield();                            // suspend thread
  }
}


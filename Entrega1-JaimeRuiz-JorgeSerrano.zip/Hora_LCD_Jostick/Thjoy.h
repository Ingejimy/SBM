#include "stm32f4xx_hal.h"

/* Flags*/
#define S_START_TIM 0x00000010 /* Detecta un flanco de subida*/
#define S_PULSACION 0x00000001
#define  S_PULSACION_FIN 0x00000100
/* Numero m�ximo de mensajes en la cola */
#define MAX_MSG_COLA 5 // En este caso como mucho tendremos 1 o 2 mensajes en cola

/* Prototipos de funciones*/
int Init_Thjoy (void);
int Init_ThPulsacionLarga (void);
int Init_Timers (void);
int Init_Timer2 (void);
int Init_MsgQueueJOY(void);

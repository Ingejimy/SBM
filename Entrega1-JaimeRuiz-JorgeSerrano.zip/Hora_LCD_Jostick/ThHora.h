/* Prototipos de funciones */

int Init_ThReloj (void);
int Init_TmReloj (void);

#include "cmsis_os2.h"                          // CMSIS RTOS header file
#include "ThLCD.h"
#include "stdio.h"
/*----------------------------------------------------------------------------
 *      Thread que leer� la cola de mensajes y representar� el gesto pulsado en el LCD
 *---------------------------------------------------------------------------*/
static MSG_LCD mensajeLCD;

osMessageQueueId_t mid_MsgQueueLCD;
osThreadId_t tid_ThLCD;                        /* thread id */

void ThLCD (void *argument);									 /* ThMsg function */

int Init_ThLCD(void) {
 
  tid_ThLCD = osThreadNew(ThLCD, NULL, NULL);
  if (tid_ThLCD == NULL) {
    return(-1);
  }
 
  return(0);
}
 
void ThLCD (void *argument) {
	
	int i;
  while (1) {
		
		i = 0;
		
		osMessageQueueGet(mid_MsgQueueLCD, &mensajeLCD, NULL, osWaitForever);
		while(mensajeLCD.Texto[i] != NULL){
			symbolToLocalBuffer(mensajeLCD.Linea, mensajeLCD.Texto[i]);
			LCD_update();
			i++;
		}
		
    osThreadYield();                            // suspend thread
  }

}

/* Inicializamos la cola de mesajes */
int Init_MsgQueueLCD(void){
	mid_MsgQueueLCD = osMessageQueueNew(MAX_MSG_LCD, sizeof(MSG_LCD), NULL);
	if (mid_MsgQueueLCD == NULL){}
		
	return(0);
}

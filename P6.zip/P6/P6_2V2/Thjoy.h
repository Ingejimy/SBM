#include "stm32f4xx_hal.h"

/* Flags*/
#define S_START_TIM 0x00000010 /* Detecta un flanco de subida*/
#define S_PULSE_END 0x00000002 /* Detecta que la pulsacion ha terminado y que el valor es estable */

/* Prototipos de funciones*/
int Init_Thjoy (void);
int Init_Timers (void);
int Init_ThWaitPulse(void);

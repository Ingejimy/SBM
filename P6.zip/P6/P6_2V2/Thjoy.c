#include "cmsis_os2.h"                          // CMSIS RTOS header file
#include "Thjoy.h"

/*----------------------------------------------------------------------------
*      Thread Driver Jostick: Para gestionar los rebotes
 *---------------------------------------------------------------------------*/
 
osThreadId_t tid_Thjoy;                        // thread id del Driver 
osThreadId_t tid_ThWaitPulse;                  // thread id para iniciar timer virtual
osTimerId_t tim_id1;   												 //Timer virtual id
static uint32_t exec1;                         // argument for the timer call back function
int pulsacion;

void Thjoy (void *argument);                   // thread function
 
int Init_Thjoy (void) {
 
  tid_Thjoy = osThreadNew(Thjoy, NULL, NULL);
  if (tid_Thjoy == NULL) {
    return(-1);
  }
 
  return(0);
}
 
void Thjoy (void *argument) {
	
	pulsacion = 0;
 
  while (1) {
		
		osThreadFlagsWait(S_PULSE_END, osFlagsWaitAll, osWaitForever);
		
		if( HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_10) == 1 ){
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
			pulsacion++;
		}
		
		if( HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_11) == 1 ){
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
			pulsacion++;
		}
		
		if( HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_12) == 1 ){
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
			pulsacion++;
		}
		
		if( HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_14) == 1 ){
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);
			pulsacion++;
		}
		
		if( HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_15) == 1 ){
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);
			pulsacion++;
		}
		
    osThreadYield();                            // suspend thread
  }
}

// One-Shoot Timer
static void Timer1_Callback (void const *arg) {
	
  // El valor es estable
	osThreadFlagsSet(tid_Thjoy, S_PULSE_END);
}

// Create and Start timers
int Init_Timers (void) {
  osStatus_t status;                            // function return status
 
  // Create one-shoot timer
  exec1 = 1U;
  tim_id1 = osTimerNew((osTimerFunc_t)&Timer1_Callback, osTimerOnce, &exec1, NULL);
  if (tim_id1 != NULL) {  // One-shot timer created
    // start timer with delay 100ms
    status = osTimerStart(tim_id1, 100U); 
    if (status != osOK) {
      return -1;
    }
  }
	
  return NULL;
}

/* Thread que espera una pulsacion del Jostick e inicia el timer virtual*/

void ThWaitPulse (void *argument);
 
int Init_ThWaitPulse(void) {
 
  tid_ThWaitPulse = osThreadNew(ThWaitPulse, NULL, NULL);
  if (tid_ThWaitPulse == NULL) {
    return(-1);
  }
 
  return(0);
}
 
void ThWaitPulse (void *argument) {
 
  while (1) {
		
		osThreadFlagsWait(S_START_TIM,osFlagsWaitAll, osWaitForever);
		osTimerStart(tim_id1, 50U);
		
    osThreadYield();                            // suspend thread
  }
}

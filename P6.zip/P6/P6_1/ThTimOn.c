#include "cmsis_os2.h"                          // CMSIS RTOS header file
#include "ThTimOn.h"

/*----------------------------------------------------------------------------
 *      ThTimOn : Cuando se recibe un flag del pulsador derecho del Jostick, redispara un timer virtual
 *---------------------------------------------------------------------------*/

extern osTimerId_t tim_id1;  
osThreadId_t tid_ThTimOn;                        // thread id
 
void ThTimOn (void *argument);                   // thread function
 
int Init_ThTimOn (void) {
 
  tid_ThTimOn = osThreadNew(ThTimOn, NULL, NULL);
  if (tid_ThTimOn == NULL) {
    return(-1);
  }
 
  return(0);
}
 
void ThTimOn (void *argument) {
 
  while (1) {
		
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET); // Insert thread code here...
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
		osTimerStart(tim_id1, 3000U);
		
		osThreadFlagsWait(S_TIM_RESET, osFlagsWaitAll, osWaitForever);
		if(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_14) == 1)
			osThreadFlagsWait(NULL, NULL, osWaitForever);
		
		 osThreadYield();                            // suspend thread
  }
}

#include "cmsis_os2.h"                          // CMSIS RTOS header file
#include "ThWaitPulse.h"
 
/*----------------------------------------------------------------------------
 *      Thread 1 'Thread_Name': Sample thread
 *---------------------------------------------------------------------------*/

extern osTimerId_t tim_id1; 
osThreadId_t tid_ThWaitPulse;                        // thread id
 
void ThWaitPulse (void *argument);                   // thread function
 
int Init_ThWaitPulse(void) {
 
  tid_ThWaitPulse = osThreadNew(ThWaitPulse, NULL, NULL);
  if (tid_ThWaitPulse == NULL) {
    return(-1);
  }
 
  return(0);
}
 
void ThWaitPulse (void *argument) {
 
  while (1) {
		
    osThreadFlagsWait(S_START_TIM,osFlagsWaitAll, osWaitForever); // Insert thread code here...
		osTimerStart(tim_id1, 50);
    osThreadYield();                            // suspend thread
  }
}

#include "stm32f4xx_hal.h"

/* Flags */
#define S_PULSE_END 0x00000002

/* Prototipo de funciones */
int Init_Timers (void);

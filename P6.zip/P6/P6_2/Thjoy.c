#include "cmsis_os2.h"                          // CMSIS RTOS header file
#include "Thjoy.h"

/*----------------------------------------------------------------------------
 *      Thjoy 'Thread_Name': Driver para la gestion de rebotes del Jostick de la mbed board
 *---------------------------------------------------------------------------*/
 
osThreadId_t tid_Thjoy;                        // thread id
int pulsacion;
	
void Thjoy (void *argument);                   // thread function
 
int Init_Thjoy (void) {
 
  tid_Thjoy = osThreadNew(Thjoy, NULL, NULL);
  if (tid_Thjoy == NULL) {
    return(-1);
  }
 
  return(0);
}
 
void Thjoy (void *argument) {
 
	pulsacion = 0;
	
  while (1) {
		
    osThreadFlagsWait(S_PULSE_END,osFlagsWaitAll, osWaitForever);		// Insert thread code here...
		pulsacion++;
		
		if( HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_10) == 1 ){
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
		}
		
		if( HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_11) == 1 ){
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
		}
		
		if( HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_12) == 1 ){
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
		}
		
		if( HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_14) == 1 ){
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);
		}
		
		if( HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_15) == 1 ){
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);
		}
		
    osThreadYield();                            // suspend thread
  }
}
